import Layout from "./layout/Layout";
import Books from "./component/Books";

function App() {
  return (
    <Layout>
      <Books />
    </Layout>
  );
}

export default App;
