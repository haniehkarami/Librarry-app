import { useState } from "react";

import { books as bookData } from "../constants/mockData";
import BookCard from "./BookCard";
import SideCard from "./SideCard";
import SearchBox from "./SearchBox";

import styles from "./Books.module.css";

function Books() {
  const [books, setBooks] = useState(bookData); //  books  را از books که بالا ایمپورت کرده بگیر
  const [liked, setLiked] = useState([]); //   هر کتابی که لایک بشه آبجکتش در این استیت قرار میگیرد
  const [search, setSearch] = useState([]);

  const handleLikeList = (book, status) => {
    // آبجکت کامل کتاب data: { title, author, image, language, pages }و وضعیت لایک را میگیرد
    if (status) {
      const newLikedList = liked.filter((i) => i.id !== book.id); // ایتم های که ایدیشون مخالف ایدی کتاب لایک شده هست رو در متغیر جدید بریز
      setLiked(newLikedList);
    } else {
      // لایک شده و باید برود در لیست محبوب ها و لایک شده ها
      setLiked((liked) => [...liked, book]);
    }
  };

  const searchHandler = () => {
    if (search) {
      // اگر سرچ ترو بود و وجود داشت
      const newBooks = bookData.filter(
        (
          book // کتابهایی که شامل سرچ هستند رو در متغیر جدید بریز
        ) => book.title.toLocaleLowerCase().includes(search)
      );
      setBooks(newBooks);
    } else {
      setBooks(bookData);
    }
  };

  return (
    <>
      <SearchBox
        search={search}
        setSearch={setSearch}
        searchHandler={searchHandler}
      />

      <div className={styles.container}>
        <div className={styles.cards}>
          {books.map(
            (
              book // این مپ روی استیت بوک انجام میشه
            ) => (
              <BookCard
                key={book.id}
                data={book}
                handleLikeList={handleLikeList}
              />
            )
          )}
        </div>
        {!!liked.length && (
          <div className={styles.favorite}>
            <h4>Favorite</h4>
            {liked.map((book) => (
              <SideCard key={book.id} data={book} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}

export default Books;
